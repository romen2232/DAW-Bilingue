import React from 'react';

const Error = () => {
    return(
        <h1>This route doesnt exist</h1>
    )
};
export default Error;